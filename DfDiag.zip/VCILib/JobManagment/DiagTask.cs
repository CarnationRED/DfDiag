﻿namespace VCILib.JobManagment
{
    public class DiagTask
    {
        public UDSTimingParams TimingParams;
        public JobSequence Jobs;
    }
}
