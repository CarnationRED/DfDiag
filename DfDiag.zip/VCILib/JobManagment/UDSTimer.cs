﻿namespace VCILib.JobManagment
{
    public class UDSTimingParams
    {
        public int P2CAN_Client;
    }
}
