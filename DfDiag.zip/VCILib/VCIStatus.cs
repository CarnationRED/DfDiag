﻿namespace VCILib
{
    public enum VCIStatus
    {
        Closed = 0,
        Connected = 1,
        Initialized = 2,
        Ready = 3,
    }
}