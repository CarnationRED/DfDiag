﻿// See https://aka.ms/new-console-template for more information
using VCILib;
using Utils;
using VCILib.Jobs;
using VCILib.JobManagment;

Test();

////新建VCI对象
//var vci = new CANalystII();
////启动VCI
//vci.Start();

//var task = DiagTaskReader.Read("热管理.csv");
//if (task != null)
//    vci.Scheduler.ExecuteJobSequence(task.Jobs);
////关闭VCI
//vci.Scheduler.AllJobsCompleted += (o, e) => vci.Stop();


void SAS()
{
    //新建VCI对象
    var vci = new CANalystII();
    //启动VCI
    vci.Start();

    //设置ID
    vci.SendAddress = 0x6f0;
    //发送一帧数据，从字符串转换为8 bytes数据
    vci.SendOneFrame("50".HexTo8ByteArray());
    Console.WriteLine("SAS解除标定");
    Thread.Sleep(500);
    //发送一帧数据，从字符串转换为8 bytes数据
    vci.SendOneFrame("30".HexTo8ByteArray());
    Console.WriteLine("SAS标定完成");
    //关闭VCI
    vci.Stop();
}

void ClearSAS()
{
    //新建VCI对象
    var vci = new CANalystII();
    //启动VCI
    vci.Start();

    //设置ID
    vci.SendAddress = 0x6f0;
    //发送一帧数据，从字符串转换为8 bytes数据
    vci.SendOneFrame("50".HexTo8ByteArray());
    Console.WriteLine("SAS解除标定");
    //关闭VCI
    vci.Stop();
}

void Test()
{
   var a= SecurityAccess.GetESK("LDP31B961MG869520". ToByteArray());
    //新建VCI对象
    var vci = new CANalystII();
    Console.WriteLine(a.ByteArrToHexString());
    //启动VCI
    vci.Start();
    //定义CAN通讯时间参数
    UDSTimingParams timer = new UDSTimingParams() { P2CAN_Client = 100 };

    //定义一个UDS诊断任务
    var job = new Job(
        SendAddress: 0x7e5,
        ResponseAddress: 0x7ed,
        //发送进入扩展会话的指令
        SendBytes: "02 10 03".HexTo8ByteArray(),//06 50 03 99 99
        SendLength: 3,
        Timer: timer
    );

    //定义接收到ECU响应后的处理逻辑
    job.Response += (object? o, IEnumerable<byte> e) =>
    {
        var arr = e.ToArray();
        //响应报文包含“50 03”时判断为 成功
        if (arr.Length >= 3 && arr[1] == 0x50 && arr[2] == 0x03)
        {
            Console.WriteLine("进入扩展会话成功");
            var failTime = 0;
            while (failTime < 3)
            {
                //定义一个UDS诊断任务，请求Seed
                var job2 = new Job(0x7e5, 0x7ed, 3, "02 27 01".HexTo8ByteArray(), timer) { RetryTime = 3 };
                job2.Response += (o, e) =>
                {
                    var arr = e.ToArray();
                    // 0  1  2  3  4  5  6
                    //06 67 01 XX XX XX XX
                    if (arr.Length == 6 && arr[1] == 0x67)
                    {
                        var seed = arr.Skip(3).Take(4).ToArray();
                        var keys = SecurityAccess.CoeffSA(seed, 0x1c302b46);
                        //发送Key
                        var job3 = new Job(0x7e5, 0x7ed, 6, "06 27 02".HexTo8ByteArray().Concat(keys), timer) { RetryTime = 3 };
                        job3.Response += (o, e) =>
                        {
                            var arr = e.ToArray();
                            // 0  1  2
                            //02 67 02
                            if (arr.Length >= 3 && arr[1] == 0x67 && arr[2] == 0x02)
                            {

                            }
                            else
                            {
                                failTime++;
                            }
                        };
                    }
                    else
                    {
                        Console.WriteLine("请求种子失败，响应不正确");
                        job2.JobFail = true;

                    }
                };
                vci.Scheduler.AddAndExecute(job2);
            }
        }
        else
            job.Error?.Invoke(vci.Scheduler, "进入扩展会话失败");
    };

    //定义任务执行报错后的处理逻辑
    job.Error += (o, e) =>
    {
        Console.WriteLine(e);
    };

    //向VCI指派任务
    vci.Scheduler.AddAndExecute(job);

    //VCI执行完任务后关闭VCI
    vci.Scheduler.AllJobsCompleted += (o, e) =>
    {
        vci.Stop();
    };
    Console.ReadKey();
}